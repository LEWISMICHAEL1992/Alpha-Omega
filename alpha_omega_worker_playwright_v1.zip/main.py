import os, time, json, traceback
from datetime import datetime
from supabase import create_client
from playwright.sync_api import sync_playwright

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE")
POLL = float(os.getenv("JOB_POLL_SECONDS", "2"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "info")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

def log(msg):
    if LOG_LEVEL in ("debug","info"):
        print(f"[{datetime.utcnow().isoformat()}] {msg}", flush=True)

def take_job():
    res = supabase.table("automation_jobs").select("*").eq("status","queued").order("created_at").limit(1).execute().data
    return res[0] if res else None

def update_job(job_id, **fields):
    fields["updated_at"] = datetime.utcnow().isoformat() + "Z"
    supabase.table("automation_jobs").update(fields).eq("id", job_id).execute()

def do_browse_search(job):
    payload = job["payload_json"]
    query = payload.get("query", "")
    max_links = int(payload.get("max_links", 5))
    if not query:
        return {"error": "missing query"}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto("https://www.google.com", timeout=60000)
        page.fill("input[name=q]", query)
        page.keyboard.press("Enter")
        page.wait_for_selector("a h3", timeout=60000)
        # Take top results
        anchors = page.query_selector_all("a h3")
        links = []
        for h3 in anchors[:max_links]:
            try:
                a = h3.evaluate_handle("e => e.closest('a')")
                href = a.evaluate("el => el.href")
                title = h3.inner_text()
                links.append({"title": title, "url": href})
            except Exception:
                continue
        browser.close()
    return {"links": links}

def do_fill_form(job):
    payload = job["payload_json"]
    url = payload.get("url")
    fields = payload.get("fields", [])
    submit_sel = payload.get("submit_selector")
    take_shot = bool(payload.get("screenshot", False))

    if not url:
        return {"error": "missing url"}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=90000)

        for f in fields:
            sel, val = f.get("selector"), f.get("value","")
            if not sel:
                continue
            page.wait_for_selector(sel, timeout=60000)
            page.fill(sel, val)

        if submit_sel:
            page.click(submit_sel)
            page.wait_for_load_state("networkidle", timeout=90000)

        out = {"final_url": page.url}
        if take_shot:
            path = f"screenshot_{job['id']}.png"
            page.screenshot(path=path, full_page=True)
            # We can base64 encode for returning via JSON (small) or upload to Supabase Storage (later)
            import base64
            with open(path, "rb") as fh:
                out["screenshot_b64"] = base64.b64encode(fh.read()).decode()

        browser.close()
    return out

HANDLERS = {
    "browse_search": do_browse_search,
    "fill_form": do_fill_form,
}

def main():
    log("Worker started. Polling for jobs...")
    while True:
        try:
            job = take_job()
            if not job:
                time.sleep(POLL); continue
            log(f"Picked job {job['id']} kind={job['kind']}")
            update_job(job["id"], status="running")
            kind = job["kind"]
            handler = HANDLERS.get(kind)
            if not handler:
                update_job(job["id"], status="failed", result_json={"error": f"Unknown kind {kind}"})
                continue
            result = handler(job)
            if result.get("error"):
                update_job(job["id"], status="failed", result_json=result)
            else:
                update_job(job["id"], status="done", result_json=result)
            log(f"Finished job {job['id']} status={'done' if not result.get('error') else 'failed'}")
        except Exception as e:
            traceback.print_exc()
            # If we had a job, mark failed
            try:
                if 'job' in locals() and job:
                    update_job(job["id"], status="failed", result_json={"error": str(e)})
            except Exception:
                pass
            time.sleep(POLL)

if __name__ == "__main__":
    main()
