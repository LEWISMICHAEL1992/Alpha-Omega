# Alpha Omega – Playwright Worker (Railway)

This worker polls Supabase for automation jobs and executes them using Playwright (Chromium).
It supports two job kinds to start with:
- `browse_search` – perform a Google search, return top links
- `fill_form` – open a URL, fill fields, optionally click submit, return final URL and optional screenshot

## 1) What you need before deployment
- A Supabase project with the `automation_jobs` table (SQL below)
- Your Replit controller can enqueue jobs by inserting into `automation_jobs`

### SQL – create automation_jobs
```sql
create table if not exists automation_jobs (
  id uuid primary key default gen_random_uuid(),
  agent_id uuid references agents(id) on delete cascade,
  kind text not null,             -- 'browse_search' | 'fill_form' | ...
  payload_json jsonb not null,    -- inputs: url, selectors, fields
  status text not null default 'queued',  -- queued|running|done|failed
  result_json jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists jobs_status_idx on automation_jobs (status, created_at);
```

## 2) Deploy to Railway (recommended)
1. Create a new **GitHub repo** (e.g., `alpha-omega-worker`).
2. Upload these files to the repo: `Dockerfile`, `requirements.txt`, `main.py`, `.env.example`.
3. Go to **Railway → New Project → Deploy from GitHub** and select your repo.
4. In **Variables**, add:
   - `SUPABASE_URL` (from Supabase Settings → API)
   - `SUPABASE_SERVICE_ROLE` (Service role key)
   - Optional: `JOB_POLL_SECONDS` (default 2)

5. Click **Deploy**. Railway will build the Dockerfile and start the worker.

## 3) How it works
- The worker polls Supabase for `automation_jobs` with `status='queued'`.
- Marks job `running`, executes, then updates `result_json` and sets `status='done'` or `failed`.
- Your Replit app can watch for completion and send results back to the user on WhatsApp.

## 4) Job payload examples

### A) browse_search
```json
{
  "kind": "browse_search",
  "payload_json": {
    "query": "5 star hotels in London Mayfair",
    "max_links": 5
  }
}
```

### B) fill_form
```json
{
  "kind": "fill_form",
  "payload_json": {
    "url": "https://example.com/form",
    "fields": [
      {"selector": "#first_name", "value": "Lewis"},
      {"selector": "#last_name", "value": "Michael"},
      {"selector": "#email", "value": "lewis@example.com"}
    ],
    "submit_selector": "button[type=submit]",
    "screenshot": true
  }
}
```

## 5) Notes
- For sensitive fields (passwords/cards), do **not** include in `payload_json`. Use an ephemeral secret exchange from your controller if/when you enable that path.
- The worker image is Chromium-ready. No extra setup needed.

## 6) Logs & debugging
In Railway → Service → Logs. You can increase verbosity by setting `LOG_LEVEL=debug`.
